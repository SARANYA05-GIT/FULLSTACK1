let products = [
    { id: 1, name: "Diamond Pendant", price: 5999, category:"necklace", image: "https://images.unsplash.com/photo-1611652022419-a9419f74343d" },
    { id: 2, name: "Gold layer chain", price: 3499, category:"chain", image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f" },
    { id: 3, name: "Rose Gold Bracelet", price: 4299, category:"bracelet", image: "https://images.unsplash.com/photo-1602751584552-8ba73aad10e1" },
    { id: 4, name: "Luxury Ring", price: 2999, category:"ring", image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e" },
    { id: 5, name: "Classic Gold drop", price: 4999, category:"earring", image: "https://images.unsplash.com/photo-1617038220319-276d3cfab638" },
    { id: 6, name: "blue luck", price: 6999, category:"necklace", image: "https://images.unsplash.com/photo-1599643477877-530eb83abc8e" },
    { id: 7, name: "Pearl Earrings", price: 2599, category:"earring", image: "https://images.unsplash.com/photo-1588444837495-c6cfeb53c4c1" },
    { id: 8, name: "Diamond Bracelet", price: 7999, category:"bracelet", image: "https://images.unsplash.com/photo-1608042314453-ae338d80c427" }
];

let productList = document.getElementById("productList");

function renderProducts(list){
    if(!productList) return;
    productList.innerHTML="";
    list.forEach(product=>{
        productList.innerHTML+=`
            <div class="product">
                <img src="${product.image}">
                <h3>${product.name}</h3>
                <p>₹${product.price}</p>
                <button onclick="addToCart(${product.id})">Add to Cart</button>
            </div>
        `;
    });
}

renderProducts(products);

function filterProducts(){
    let search=document.getElementById("searchInput").value.toLowerCase();
    let category=document.getElementById("categoryFilter").value;

    let filtered=products.filter(p=>
        p.name.toLowerCase().includes(search) &&
        (category==="all" || p.category===category)
    );

    renderProducts(filtered);
}

function addToCart(id){
    let cart=JSON.parse(localStorage.getItem("cart"))||[];
    let existing=cart.find(item=>item.id===id);

    if(existing){
        existing.quantity+=1;
    }else{
        let product=products.find(p=>p.id===id);
        cart.push({...product,quantity:1});
    }

    localStorage.setItem("cart",JSON.stringify(cart));
    alert("Added to cart!");
}

function displayCart(){
    let cart=JSON.parse(localStorage.getItem("cart"))||[];
    let cartDiv=document.getElementById("cartItems");
    let total=0;
    if(!cartDiv) return;

    cartDiv.innerHTML="";

    cart.forEach(item=>{
        total+=item.price*item.quantity;

        cartDiv.innerHTML+=`
            <div class="product">
                <img src="${item.image}">
                <h3>${item.name}</h3>
                <p>₹${item.price}</p>
                <p>Quantity: ${item.quantity}</p>
                <button onclick="changeQty(${item.id},1)">+</button>
                <button onclick="changeQty(${item.id},-1)">-</button>
                <button onclick="removeItem(${item.id})">Remove</button>
            </div>
        `;
    });

    document.getElementById("total").innerText="Total: ₹"+total;
}

function changeQty(id,change){
    let cart=JSON.parse(localStorage.getItem("cart"));
    let item=cart.find(p=>p.id===id);

    item.quantity+=change;

    if(item.quantity<=0){
        cart=cart.filter(p=>p.id!==id);
    }

    localStorage.setItem("cart",JSON.stringify(cart));
    displayCart();
}

function removeItem(id){
    let cart=JSON.parse(localStorage.getItem("cart"));
    cart=cart.filter(p=>p.id!==id);
    localStorage.setItem("cart",JSON.stringify(cart));
    displayCart();
}